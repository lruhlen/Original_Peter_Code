

        implicit real*8(a-h,o-z), integer*4(i-n)
        parameter (ngals=1,nb=100000)
